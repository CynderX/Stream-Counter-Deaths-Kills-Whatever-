* PART 1 - SOFTWARE SETUP:

	Firstly, thank you for choosing my Stream Counter! Secondly, you need to do just a couple things to be fully set up:


	1- You'll need Python 3 installed to run this program; you can download Python 3 here: https://www.python.org/downloads/

	2- For the hotkeys, you'll need to install AutoHotkey; you can download AutoHotkey here:  https://www.autohotkey.com/


	*AutoHotkey isn't required for the program to run, but it will make your life a lot easier - I'll expand on this later.



* PART 2 - USING THE COUNTER:

	This counter can store values for many different things at once; to let it know what value it needs to update, enter the name of the count in the Current Count.txt file - this can be found in the 'Counts' folder.
	If this is a new count, a '.txt' file will automatically be created to store the value.


	2.1 - WITH HOTKEYS (SEE PART 3):
		
		If you choose to use hotkeys, press them and the count will change as you wish!

	2.2 - WITHOUT HOTKEYS:

		If you choose not to use hotkeys, double-click the required .py file ('AddCounter'/'SubtractCounter'/'ResetCounter'). The count will then be adjusted as you wish!



* PART 3 - HOTKEYS:

	In the 'Hotkeys' file, I have included three AutoHotkey scripts; these bind 'Ctrl+1', 'Ctrl+2' and 'Ctrl+3' to run 'AddCounter', 'SubtractCounter', and 'ResetCounter' respectivley. 

	For the hotkeys to work, you will need to replace the path in each hotkey script with the path to the related Python file. You're also free to read up on AutoHotkey and change the key combinations if you wish.
	
	If you want your hotkeys to run automatically on startup, press 'Win+R', type 'shell:startup', and click 'OK'; paste your hotkeys here and delete the original 'Hotkeys' file. This is optional, but if you don't do this, you will have to run each hotkey script once before you want to use the counter.



* PART 4 - OBS SETUP:

	To show the counter on stream, open OBS and add a new 'Text (GDI+)' source. Tick the 'Read from file' checkbox, and select the .txt file the count will be read from - this can be found in the 'Counts' folder. 

	If this is for a new count, run either the 'ResetCounter' or 'SubtractCounter' .py file after writing the name of the count in 'Current Counter.txt' file. Running the 'AddCounter'.py file here will create a count that starts on 1, instead of 0.

	After doing this, you can adjust the visual settings of the counter (font, colour ect. within OBS.)


* PART 5 - THANKS AND CREDITING:

	I know I opened with this, but thanks again for choosing to use my counter - it means a lot to me. If you use it for streaming, I would be very grateful if you could credit me (x_Cynder on Twitch!), but there's no obligation to do this. I hope you have fun using it!