import os.path

CWD = os.path.dirname(os.getcwd())
NewCWD = (CWD + "/Counts/")
os.chdir(NewCWD)

CurrentCountPath = os.path.join(NewCWD,"Current Count.txt")

f = open(CurrentCountPath,"r")

Count = f.readline()
f.close()

fileName = "%s.txt" % Count

if os.path.isfile(fileName):

    ThisCount = "0"
    f = open(fileName,"w")
    f.write(ThisCount)
    f.close()

    quit()

else:
    f = open(fileName,"w")
    f.write("0")
    f.close()



