import os.path

CWD = os.path.dirname(os.getcwd())
NewCWD = (CWD + "/Counts/")
os.chdir(NewCWD)

CurrentCountPath = os.path.join(NewCWD,"Current Count.txt")

f = open(CurrentCountPath,"r")

Count = f.readline()
f.close()

fileName = "%s.txt" % Count

if os.path.isfile(fileName):
    f = open(fileName,"r")

    ThisCount = f.readline()
    f.close()

    IntThisCount = int(ThisCount)
    IntThisCount = (IntThisCount + 1)
    NewCount = str(IntThisCount)

    f = open(fileName,"w")
    f.write(NewCount)
    f.close()
    
else:
    f = open(fileName,"w")
    f.write("1")
    f.close()
    
    



